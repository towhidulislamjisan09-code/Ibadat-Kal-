package com.example.ibadatkal

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.ads.*
import com.google.android.gms.location.*
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var bannerAdView: AdView
    private var interstitialAd: InterstitialAd? = null

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val interstitialAdUnitId = "ca-app-pub-2881750910428957/8144203928"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MobileAds.initialize(this) {}

        webView = findViewById(R.id.prayerWebView)
        bannerAdView = findViewById(R.id.bannerAdView)

        val adRequest = AdRequest.Builder().build()
        bannerAdView.loadAd(adRequest)

        loadInterstitialAd()

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // লোকেশন পারমিশন চেক এবং নাও
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1001
            )
        } else {
            fetchLocationAndLoadPrayerTimes()
        }
    }

    private fun fetchLocationAndLoadPrayerTimes() {
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                loadPrayerTimes(location.latitude, location.longitude)
            } else {
                Toast.makeText(this, "Unable to get location", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadPrayerTimes(latitude: Double, longitude: Double) {
        val url = "https://api.aladhan.com/v1/timings?latitude=$latitude&longitude=$longitude&method=2"

        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Failed to load prayer times", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val json = response.body?.string()
                if (json != null) {
                    val jsonObject = JSONObject(json)
                    val timings = jsonObject.getJSONObject("data").getJSONObject("timings")
                    val fajr = timings.getString("Fajr")
                    val dhuhr = timings.getString("Dhuhr")
                    val asr = timings.getString("Asr")
                    val maghrib = timings.getString("Maghrib")
                    val isha = timings.getString("Isha")

                    // এখন তুমি চাইলে timings WebView বা TextView-এ দেখাতে পারো
                    runOnUiThread {
                        val html = """
                            <html>
                            <body style="text-align:center; font-size:18px;">
                            <h2>নামাজের সময়</h2>
                            <p>ফজর: $fajr</p>
                            <p>যোহর: $dhuhr</p>
                            <p>আসর: $asr</p>
                            <p>মাগরিব: $maghrib</p>
                            <p>ইশা: $isha</p>
                            </body>
                            </html>
                        """.trimIndent()
                        webView.settings.javaScriptEnabled = true
                        webView.loadData(html, "text/html; charset=utf-8", "UTF-8")
                    }
                }
            }
        })
    }

    private fun loadInterstitialAd() {
        InterstitialAd.load(this, interstitialAdUnitId, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    interstitialAd = null
                }
            })
    }

    override fun onBackPressed() {
        interstitialAd?.let {
            it.show(this)
            it.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    finish()
                }
            }
        } ?: run {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        bannerAdView.destroy()
        super.onDestroy()
    }

    // লোকেশন পারমিশন রিকোয়েস্ট রেসপন্স হ্যান্ডেল
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            fetchLocationAndLoadPrayerTimes()
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
        }
    }
}